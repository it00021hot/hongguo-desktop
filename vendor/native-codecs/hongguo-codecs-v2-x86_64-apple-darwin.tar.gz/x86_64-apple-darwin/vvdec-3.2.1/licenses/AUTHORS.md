# Authors

* Adam Wieckowski, @adamjw24, Fraunhofer HHI
* Gabriel Hege, , Fraunhofer HHI
* Christian Bartnik, , Fraunhofer HHI
* Christian Stoffers, , Fraunhofer HHI
* Christian Lehmann, , Fraunhofer HHI
* Valeri George, , Fraunhofer HHI
* Jens Güther, , Fraunhofer HHI
* X Rayleigh, @xrayleigh2000,
* Matthieu Sauer, ,
* Florian Eisenreich, , Fraunhofer HHI
* Philippe de Lagrange, @delagrangep, InterDigital
* David Maseda Neira, ,
* Athulya Raj Raji Mohini, @athulya-arm, Arm
* Elias Balint, @balintelias, Arm
* Micro Daryl Robles, @micro-arm, Arm
* Li Zhang, @lizhang-arm, Arm
